export default function Home() {
  return (
    <div className="bg-gray-900 text-white font-sans">
      {/* Hero Section */}
      <section className="h-screen bg-[url('/barbershop.jpg')] bg-cover bg-center flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-5xl font-bold mb-4">Rico's Refined Cuts</h1>
          <p className="text-xl">Sharp cuts. Classic vibes.</p>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 px-8">
        <h2 className="text-3xl font-semibold mb-4">About Us</h2>
        <p className="text-lg text-gray-400">
          At Rico's Refined Cuts, we blend tradition with modern style. From fades to beard trims, we’ve got you covered.
        </p>
      </section>

      {/* Services Section */}
      <section className="py-16 px-8 bg-gray-800">
        <h2 className="text-3xl font-semibold mb-4">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-medium">Classic Haircut</h3>
            <p className="text-gray-400">$25 - Clean and sharp.</p>
          </div>
          <div>
            <h3 className="text-xl font-medium">Beard Trim</h3>
            <p className="text-gray-400">$15 - Sculpted to perfection.</p>
          </div>
          <div>
            <h3 className="text-xl font-medium">Hot Towel Shave</h3>
            <p className="text-gray-400">$20 - A classic experience.</p>
          </div>
          <div>
            <h3 className="text-xl font-medium">Kids Cut</h3>
            <p className="text-gray-400">$18 - Fresh cuts for the little ones.</p>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-16 px-8">
        <h2 className="text-3xl font-semibold mb-4">Gallery</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <img src="/cut1.jpg" alt="Cut 1" className="rounded-xl" />
          <img src="/cut2.jpg" alt="Cut 2" className="rounded-xl" />
          <img src="/cut3.jpg" alt="Cut 3" className="rounded-xl" />
          <img src="/cut4.jpg" alt="Cut 4" className="rounded-xl" />
        </div>
      </section>

      {/* Booking Section */}
      <section className="py-16 px-8 bg-gray-800">
        <h2 className="text-3xl font-semibold mb-4">Book an Appointment</h2>
        <form className="space-y-4">
          <input type="text" placeholder="Name" className="w-full bg-gray-700 rounded-xl p-2" />
          <input type="text" placeholder="Service" className="w-full bg-gray-700 rounded-xl p-2" />
          <input type="date" className="w-full bg-gray-700 rounded-xl p-2" />
          <button className="bg-red-500 w-full py-2 rounded-xl text-white">Book Now</button>
        </form>
      </section>

      {/* Contact Section */}
      <footer className="py-8 px-8 bg-gray-900 text-center">
        <p className="text-gray-400">123 Main St, Cityville | (555) 123-4567</p>
        <p className="text-gray-400">Follow us on Instagram @ricosrefinedcuts</p>
      </footer>
    </div>
  )
}